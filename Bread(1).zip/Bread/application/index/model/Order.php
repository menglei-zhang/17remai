<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/16
 * Time: 17:13
 */

namespace app\index\model;

use think\Model;
use app\index\model\Bread;
use app\index\model\Record;

class Order extends Model
{
	public function buy($where)
	{	
		$this -> startTrans();
		$Bread = new Bread();
		$breadAll = $Bread->where(['status' => 0, 'activate' => 0])->select();
		$count = count($breadAll);

		// 验证商品数量是否充足
		if($where['gNum'] > $count){
			return echoArr(500, '商品数量不足');
		}

		foreach($breadAll as $key => $val){
			$data['order_sn'] = $this->getOrderNo();
			$data['user_id'] = $where['uid'];
			$data['goods_name'] = $val['name'];
			$data['goods_price'] = $val['money'];
			$data['goods_num'] = $where['gNum'];
			$data['order_count'] = $data['goods_price'] * $data['goods_num'];
			$data['add_time'] = time();
		}

		// 生成订单
		$result = $this->allowField(true)->isUpdate(false)->save($data);
		if(false === $result){
			$this -> rollback();
			return echoArr(500, '购买失败');
		}

		$this -> commit();
		return $data;
	}


	// 生成订单号
    public function getOrderNo()
    {
        while (true) {
            $order_no = date('YmdHis') . rand(100000, 999999);
            $exist_order_no = $this->where('order_sn', $order_no)->find();
            if (!$exist_order_no) break;
        }
        return $order_no;
    }
}




		// // 余额明细产生记录
		// $Record = new Record();
		// $info['user_id'] = $where['uid'];
		// $info['trade_type'] = '购买面包券';
		// $info['user_money'] = $result['order_count'];
		// $info['budget'] = 1;
		// $info['add_time'] = time();

		// $res = $Record->allowField(true)->isUpdate(false)->save($info);

