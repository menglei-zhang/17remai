<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/16
 * Time: 17:13
 */

namespace app\index\model;

use think\Model;

class Record extends Model
{
	public function resList($data)
	{
		$data = $this->where('user_id', $data['uid'])->field('trade_type,user_money,add_time')->select();

		foreach($data as $key =>$val){
			$data[$key]['add_time'] = date('Y-m-d H:i:s', $val['add_time']);
		}

		return $data;
	}
}