<?php

namespace app\index\controller;

use think\Request;
use think\Controller;
use think\facade\Cache;
use app\index\model\Users;
use app\index\model\Order;
use app\index\model\OrderGoods;
use app\index\model\Bread;
use app\index\model\Coupon;
use app\index\model\Record;

class Myuser extends Controller
{
	// 用户信息
    public function userInfo()
    {
        if ($this->request->isPost()) {
            $token = $this->request->header('tokenAccess');
            if(empty($token)){
                return json(echoArr(300, 'tokenAccess失效'));
            }
            $openId = Cache::get($token);
            $userModel = new Users();
            $data = $userModel->getUserFind($openId);
            return json($data);
        } else {
            return json(echoArr(500, '非法请求'));
        }
    }
  

    // 图片上传
    public function upImg()
    {
        $file = input('file.img');
        if($file){
            $info = $file->move('./weixin/');
            if($info){
                $file = $info->getSaveName();
                $ip = $_SERVER['REQUEST_SCHEME'] . '://' .$_SERVER['SERVER_NAME'];
                $temp['0'] = $ip.'/weixin/'.$file;
                $res = ['errCode' => 0, 'errMsg' => '图片上传成功', 'file' => $temp];
                return json($res);
            }
        }
    }


    // 查看余额
    public function balance()
    {
        $input = input();

        // 新人礼券
        $Records = new Record();
        $Record = $Records->where(['user_id'=>$input['uid'], 'trade_type'=>'新人礼券'])->field('user_money')->find();
        if($Record){
            $dataAll['newpeople_money'] = $Record['user_money'];
        }
        
        // 活动礼券
        $coupons = new Coupon();
        $coupon = $coupons->where('user_id', $input['uid'])->sum('money');
        if($coupon){
            $dataAll['coupon_money'] = $coupon;
        }
        
        // 面包券
        $breads = new Bread();
        $bread = $breads->where('user_id', $input['uid'])->sum('money');
        if($bread){
            $dataAll['bread_money'] = $bread;
        }
        
        // 用户余额
        $users = new Users();
        $user = $users->where('id', $input['uid'])->sum('user_money');
        
        $dataAll['user_money'] = $user;
    	return json($dataAll);
    }
}
