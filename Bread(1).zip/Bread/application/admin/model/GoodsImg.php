<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/15
 * Time: 15:44
 */

namespace app\admin\model;

use think\Model;

class GoodsImg extends Model
{

}