<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/9/26
 * Time: 15:48
 */

namespace app\admin\model;

use think\Model;
use app\admin\validate\Order as Vali;

class Order extends Model
{
	/**
	 * 订单列表
	 */
	public function resList($order_sn)
	{
		$query = $this->where(1);
		unset($order_sn['page']);
		if($order_sn){
			if($order_sn['order_sn']){
				// 查询订单号，模糊查询
				$query->where('order_sn', 'like', "%{$order_sn['order_sn']}%")->select();
			}
		}

		$list = $query->order('id desc')->paginate(10, false, ['query'=>request()->param()]);

		return $list;
	}


	public function resFind($id)
    {
        $res = $this -> find($id);

        return $res;
    }

}