<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/9/13
 * Time: 9:50
 */

namespace app\admin\model;


use think\Model;

class AdminRuleClassify extends Model
{

}