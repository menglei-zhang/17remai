<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/9/18
 * Time: 11:11
 */  
namespace app\index\controller;

use think\Controller;

class Record extends Controller
{
	public function index()
	{
		$data = input();

		$result = model('Record')->resList($data);

		return json($result);
	}
}