<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/9/14
 * Time: 11:28
 */

namespace app\admin\model;


use think\Model;

class AdminUserRole extends Model
{

}