<?php

namespace app\index\controller;

use think\Controller;
use app\index\model\Banner;
use app\index\model\Bread;
use app\index\model\Goods;
use app\index\model\GoodsImg;
use app\index\model\Machine;

class HomePage extends Controller
{
    /**
     * @return 首页
     */
    public function index()
    {
        // 首页搜索框
        $info = input('post.');
        $Machine = new Machine();
        $result = $Machine->resFind($info);
        
        // 获取banner图
        $BannerModel = new Banner();
        $list = $BannerModel->resList();

        // 购买面包券
        $BreadModel = new Bread();
        $data = $BreadModel->getBread();
       
        // 商品展示
        $GoodsModel = new Goods();
        $GoodsData = $GoodsModel->getGoodsAll();

        $dataAll['Machine'] = $result;
        $dataAll['banner'] = $list;
        $dataAll['bread'] = $data;
        $dataAll['GoodsData'] = $GoodsData;
        return json($dataAll);
    }


    /**
     * @return 商品图片
     */
    public function goodsImg()
    {
        $data = input();

        $GoodsImg = new GoodsImg();
        $goodsImg = $GoodsImg->getGoodsImg($data);

        return json($goodsImg);
    }
}

