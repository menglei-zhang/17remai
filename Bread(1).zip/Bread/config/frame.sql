/*
Navicat MySQL Data Transfer

Source Server         : Rain
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : frame

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-11-21 14:15:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for frame_ad
-- ----------------------------
DROP TABLE IF EXISTS `frame_ad`;
CREATE TABLE `frame_ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position_id` int(11) NOT NULL DEFAULT '0' COMMENT '广告位置id',
  `ad_name` varchar(30) NOT NULL DEFAULT '' COMMENT '广告名称',
  `ad_link` varchar(200) NOT NULL DEFAULT '' COMMENT '链接地址',
  `ad_img` varchar(100) NOT NULL DEFAULT '' COMMENT '广告图片',
  `link_add` varchar(30) NOT NULL DEFAULT '' COMMENT '添加人',
  `link_email` varchar(30) NOT NULL DEFAULT '' COMMENT '添加人邮箱',
  `link_phone` varchar(30) NOT NULL DEFAULT '' COMMENT '添加人电话',
  `click_count` int(11) NOT NULL DEFAULT '0' COMMENT '点击量',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `target` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否在新窗口打开',
  `bgcolor` varchar(20) NOT NULL DEFAULT '' COMMENT '背景颜色',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_ad
-- ----------------------------

-- ----------------------------
-- Table structure for frame_admin_classify
-- ----------------------------
DROP TABLE IF EXISTS `frame_admin_classify`;
CREATE TABLE `frame_admin_classify` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品分类id',
  `classify_name` varchar(20) NOT NULL DEFAULT '' COMMENT '商品分类名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `classify_name` (`classify_name`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_admin_classify
-- ----------------------------
INSERT INTO `frame_admin_classify` VALUES ('22', '用户设置');
INSERT INTO `frame_admin_classify` VALUES ('24', '首页展示');

-- ----------------------------
-- Table structure for frame_admin_role
-- ----------------------------
DROP TABLE IF EXISTS `frame_admin_role`;
CREATE TABLE `frame_admin_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `role_name` varchar(20) NOT NULL DEFAULT '' COMMENT '角色名称',
  `describe` varchar(80) NOT NULL DEFAULT '' COMMENT '角色详情',
  `create_time` varchar(20) NOT NULL DEFAULT '' COMMENT '创建角色时间',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '角色状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_admin_role
-- ----------------------------
INSERT INTO `frame_admin_role` VALUES ('4', '行政经理', '管理用户设置', '1540347572', '1');
INSERT INTO `frame_admin_role` VALUES ('1', '超级管理员', '至高无上的权利', '1536908003', '1');
INSERT INTO `frame_admin_role` VALUES ('15', '员工', '后台的基本功能', '1540374824', '1');

-- ----------------------------
-- Table structure for frame_admin_role_rule
-- ----------------------------
DROP TABLE IF EXISTS `frame_admin_role_rule`;
CREATE TABLE `frame_admin_role_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色和权限关联id',
  `role_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '角色id',
  `rule_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '权限id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=259 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_admin_role_rule
-- ----------------------------
INSERT INTO `frame_admin_role_rule` VALUES ('237', '4', '37');
INSERT INTO `frame_admin_role_rule` VALUES ('236', '4', '38');
INSERT INTO `frame_admin_role_rule` VALUES ('235', '4', '39');
INSERT INTO `frame_admin_role_rule` VALUES ('234', '4', '40');
INSERT INTO `frame_admin_role_rule` VALUES ('233', '4', '41');
INSERT INTO `frame_admin_role_rule` VALUES ('232', '4', '42');
INSERT INTO `frame_admin_role_rule` VALUES ('254', '15', '37');
INSERT INTO `frame_admin_role_rule` VALUES ('231', '4', '43');
INSERT INTO `frame_admin_role_rule` VALUES ('230', '4', '44');
INSERT INTO `frame_admin_role_rule` VALUES ('253', '15', '38');
INSERT INTO `frame_admin_role_rule` VALUES ('229', '4', '45');
INSERT INTO `frame_admin_role_rule` VALUES ('228', '4', '46');
INSERT INTO `frame_admin_role_rule` VALUES ('227', '4', '47');
INSERT INTO `frame_admin_role_rule` VALUES ('226', '4', '48');
INSERT INTO `frame_admin_role_rule` VALUES ('225', '4', '49');
INSERT INTO `frame_admin_role_rule` VALUES ('224', '4', '50');
INSERT INTO `frame_admin_role_rule` VALUES ('223', '4', '51');
INSERT INTO `frame_admin_role_rule` VALUES ('222', '4', '52');
INSERT INTO `frame_admin_role_rule` VALUES ('221', '4', '53');
INSERT INTO `frame_admin_role_rule` VALUES ('220', '4', '54');
INSERT INTO `frame_admin_role_rule` VALUES ('219', '4', '55');
INSERT INTO `frame_admin_role_rule` VALUES ('252', '15', '54');
INSERT INTO `frame_admin_role_rule` VALUES ('251', '15', '55');
INSERT INTO `frame_admin_role_rule` VALUES ('198', '16', '55');
INSERT INTO `frame_admin_role_rule` VALUES ('199', '16', '53');

-- ----------------------------
-- Table structure for frame_admin_rule
-- ----------------------------
DROP TABLE IF EXISTS `frame_admin_rule`;
CREATE TABLE `frame_admin_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限id',
  `rule_name` varchar(10) NOT NULL DEFAULT '' COMMENT '权限名称',
  `controller` varchar(30) NOT NULL DEFAULT '' COMMENT '权限',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rule_name` (`rule_name`,`controller`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_admin_rule
-- ----------------------------
INSERT INTO `frame_admin_rule` VALUES ('45', '角色状态', 'Admin@role_status');
INSERT INTO `frame_admin_rule` VALUES ('44', '角色编辑', 'Admin@role_form');
INSERT INTO `frame_admin_rule` VALUES ('43', '角色展示', 'Admin@role');
INSERT INTO `frame_admin_rule` VALUES ('42', '用户状态', 'Admin@user_status');
INSERT INTO `frame_admin_rule` VALUES ('37', '登录', 'Admin@login');
INSERT INTO `frame_admin_rule` VALUES ('38', '退出登录', 'Admin@loginOut');
INSERT INTO `frame_admin_rule` VALUES ('39', '管理员展示', 'Admin@user');
INSERT INTO `frame_admin_rule` VALUES ('40', '管理员编辑', 'Admin@user_form');
INSERT INTO `frame_admin_rule` VALUES ('41', '管理员删除', 'Admin@user_del');
INSERT INTO `frame_admin_rule` VALUES ('46', '角色删除', 'Admin@role_del');
INSERT INTO `frame_admin_rule` VALUES ('47', '权限展示', 'Admin@rule');
INSERT INTO `frame_admin_rule` VALUES ('48', '权限请求', 'Admin@rule_actions');
INSERT INTO `frame_admin_rule` VALUES ('49', '权限编辑', 'Admin@rule_form');
INSERT INTO `frame_admin_rule` VALUES ('50', '权限删除', 'Admin@rule_del');
INSERT INTO `frame_admin_rule` VALUES ('51', '权限分类展示', 'Admin@classify');
INSERT INTO `frame_admin_rule` VALUES ('52', '权限分类编辑', 'Admin@classify_form');
INSERT INTO `frame_admin_rule` VALUES ('53', '权限分类删除', 'Admin@classify_del');
INSERT INTO `frame_admin_rule` VALUES ('54', '首页模块', 'Index@index');
INSERT INTO `frame_admin_rule` VALUES ('55', '欢迎页', 'Index@welcome');

-- ----------------------------
-- Table structure for frame_admin_rule_classify
-- ----------------------------
DROP TABLE IF EXISTS `frame_admin_rule_classify`;
CREATE TABLE `frame_admin_rule_classify` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限和权限分类关联id',
  `rule_id` int(11) NOT NULL DEFAULT '0' COMMENT '权限id',
  `classify_id` int(11) NOT NULL DEFAULT '0' COMMENT '权限分类id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_admin_rule_classify
-- ----------------------------
INSERT INTO `frame_admin_rule_classify` VALUES ('33', '46', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('32', '45', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('31', '44', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('30', '43', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('29', '42', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('24', '37', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('25', '38', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('26', '39', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('27', '40', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('28', '41', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('34', '47', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('35', '48', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('36', '49', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('37', '50', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('38', '51', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('39', '52', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('40', '53', '22');
INSERT INTO `frame_admin_rule_classify` VALUES ('41', '54', '24');
INSERT INTO `frame_admin_rule_classify` VALUES ('42', '55', '24');

-- ----------------------------
-- Table structure for frame_admin_user
-- ----------------------------
DROP TABLE IF EXISTS `frame_admin_user`;
CREATE TABLE `frame_admin_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '管理员id',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '管理员名称',
  `password` varchar(50) NOT NULL DEFAULT '' COMMENT '管理员密码',
  `create_time` varchar(20) NOT NULL DEFAULT '' COMMENT '管理员创建时间',
  `phone` varchar(11) NOT NULL DEFAULT '' COMMENT '管理员手机',
  `email` varchar(20) NOT NULL DEFAULT '' COMMENT '管理员邮箱',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`phone`,`email`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_admin_user
-- ----------------------------
INSERT INTO `frame_admin_user` VALUES ('1', 'admin', 'bd54e12d3cb24210fdfb532248623c96', '1536908003', '15870659394', 'wzy1209@outlook.com', '1');
INSERT INTO `frame_admin_user` VALUES ('91', '123412', '7ae3963de2e291567e8670d98082990d', '1540266268', '17859632578', 'wzy1209@outlook.com', '1');

-- ----------------------------
-- Table structure for frame_admin_user_role
-- ----------------------------
DROP TABLE IF EXISTS `frame_admin_user_role`;
CREATE TABLE `frame_admin_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户和角色关联id',
  `user_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户id',
  `role_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '角色id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_admin_user_role
-- ----------------------------
INSERT INTO `frame_admin_user_role` VALUES ('36', '1', '1');
INSERT INTO `frame_admin_user_role` VALUES ('44', '91', '15');

-- ----------------------------
-- Table structure for frame_ad_position
-- ----------------------------
DROP TABLE IF EXISTS `frame_ad_position`;
CREATE TABLE `frame_ad_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position_name` varchar(50) NOT NULL DEFAULT '' COMMENT '广告位名称',
  `ad_width` smallint(5) NOT NULL DEFAULT '0' COMMENT '广告宽度',
  `ad_height` smallint(5) NOT NULL DEFAULT '0' COMMENT '广告高度',
  `position_desc` varchar(200) NOT NULL DEFAULT '' COMMENT '广告位描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `position_name` (`position_name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_ad_position
-- ----------------------------

-- ----------------------------
-- Table structure for frame_article
-- ----------------------------
DROP TABLE IF EXISTS `frame_article`;
CREATE TABLE `frame_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL DEFAULT '0' COMMENT '文章分类id',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '文章标题',
  `thumbnail` varchar(100) NOT NULL DEFAULT '' COMMENT '新闻的缩略图',
  `desc` text NOT NULL COMMENT '文章内容',
  `author` varchar(30) NOT NULL DEFAULT '' COMMENT '文章作者',
  `author_email` varchar(30) NOT NULL DEFAULT '' COMMENT '文章作者邮箱',
  `add_time` varchar(20) NOT NULL DEFAULT '' COMMENT '文章发布时间',
  `keywords` varchar(200) NOT NULL DEFAULT '' COMMENT '关键词',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `link` varchar(100) NOT NULL DEFAULT '' COMMENT '文章链接',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_article
-- ----------------------------

-- ----------------------------
-- Table structure for frame_article_cat
-- ----------------------------
DROP TABLE IF EXISTS `frame_article_cat`;
CREATE TABLE `frame_article_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章分类名称',
  `name` varchar(20) NOT NULL,
  `sort` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `desc` varchar(200) NOT NULL DEFAULT '' COMMENT '分类描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_article_cat
-- ----------------------------
INSERT INTO `frame_article_cat` VALUES ('10', '商城说明', '0', '此个商城的主要说明，以及下单的整个流程');

-- ----------------------------
-- Table structure for frame_cart
-- ----------------------------
DROP TABLE IF EXISTS `frame_cart`;
CREATE TABLE `frame_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `goods_sn` varchar(100) NOT NULL DEFAULT '' COMMENT '商品编号',
  `goods_name` varchar(100) NOT NULL DEFAULT '' COMMENT '商品名称',
  `market_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `goods_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '本店价',
  `goods_integral` int(11) NOT NULL DEFAULT '0' COMMENT '商品积分数 0则不是积分商品',
  `member_goods_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '会员折扣价',
  `goods_num` int(11) NOT NULL DEFAULT '1' COMMENT '购买数量',
  `selected` tinyint(1) NOT NULL DEFAULT '0' COMMENT '购物车选中状态',
  `add_time` varchar(30) NOT NULL DEFAULT '' COMMENT '添加购物车时间',
  `prom_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 普通订单,1 限时抢购, 2 团购 , 3 促销优惠',
  `spec_key` varchar(30) NOT NULL DEFAULT '' COMMENT '商品规格',
  `spec_key_name` varchar(100) NOT NULL DEFAULT '' COMMENT '商品规格组合名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_cart
-- ----------------------------

-- ----------------------------
-- Table structure for frame_comment
-- ----------------------------
DROP TABLE IF EXISTS `frame_comment`;
CREATE TABLE `frame_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `email` varchar(60) NOT NULL DEFAULT '' COMMENT 'email邮箱',
  `username` varchar(60) NOT NULL DEFAULT '' COMMENT '用户名称',
  `content` text NOT NULL COMMENT '评价内容',
  `add_time` varchar(30) NOT NULL DEFAULT '' COMMENT '评价时间',
  `ip_address` varchar(20) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示此评价',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父级id',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '评论用户',
  `img` text NOT NULL COMMENT '晒单图片',
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单id',
  `logistics_rank` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发货评价等级',
  `deliver_rank` tinyint(1) NOT NULL DEFAULT '0' COMMENT '物流评价等级',
  `goods_rank` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品评价等级',
  `service_rank` tinyint(1) NOT NULL DEFAULT '0' COMMENT '服务态度评价等级',
  `zan_num` int(11) NOT NULL DEFAULT '0' COMMENT '被赞数',
  `zan_userid` varchar(255) NOT NULL DEFAULT '' COMMENT '点赞用户id',
  `is_anonymous` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否匿名评价',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_comment
-- ----------------------------
INSERT INTO `frame_comment` VALUES ('35', '34', 'wzy1209@outlook.com', 'feilx', '还行', '1542608091', '127.0.0.1', '1', '0', '16', '', '0', '0', '0', '0', '0', '0', '', '0');
INSERT INTO `frame_comment` VALUES ('36', '34', 'wzy1209@outlook.com', 'admin', '我就知道还行', '1542617330', '127.0.0.1', '1', '35', '0', '', '0', '0', '0', '0', '0', '0', '', '0');

-- ----------------------------
-- Table structure for frame_config
-- ----------------------------
DROP TABLE IF EXISTS `frame_config`;
CREATE TABLE `frame_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(30) NOT NULL DEFAULT '' COMMENT '键名',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '名称',
  `value` text NOT NULL COMMENT '键值',
  `inc_type` varchar(20) NOT NULL DEFAULT '' COMMENT '配置商城设置类型',
  `desc` varchar(200) NOT NULL DEFAULT '' COMMENT '此行的描述',
  `input_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '输入类型，0为文本框，1为图片',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_config
-- ----------------------------
INSERT INTO `frame_config` VALUES ('1', 'record_no', '网站备案号', '粤12345678号', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('2', 'store_name', '网站名称', '诗丹德', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('3', 'store_logo', '网站logo', '20181031\\\\760fb71880e9e7577b047ea6bc2a87b7.png', 'web_info', '', '1');
INSERT INTO `frame_config` VALUES ('4', 'store_icon', '网站图片ico', '20181119\\\\557bc5924a6589a1786de38ef3258e47.jpg', 'web_info', '', '1');
INSERT INTO `frame_config` VALUES ('5', 'store_title', '网站标题', '诗丹德', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('6', 'store_keyword', '网站关键词', '商城，商品，出售', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('7', 'store_desc', '网站描述', '测试测试测试测试测试测试测试测试测试测试测试', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('8', 'admin_login_name', '后台登录名称', '中俄商城后台登录', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('9', 'admin_home_name', '后台页面名称', '后台管理系统', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('10', 'hot_keywords', '首页热门搜索词', '手机|小米|iphone|三星|华为|冰箱', 'basic_setup', '请使用 \"|\" 间隔', '0');
INSERT INTO `frame_config` VALUES ('11', 'contact', '联系电话', '187345487905', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('12', 'admin_home_title', '后台页面标题', '中俄后台管理系统', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('13', 'footer_info', '网站底部信息', '© 加美华 版本所有', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('14', 'company_address', '公司地址', '上海市宝山区智慧湾科创园', 'web_info', '', '0');
INSERT INTO `frame_config` VALUES ('15', 'company_email', '邮箱', '6236479284@QQ.COM', 'web_info', '', '0');

-- ----------------------------
-- Table structure for frame_coupon
-- ----------------------------
DROP TABLE IF EXISTS `frame_coupon`;
CREATE TABLE `frame_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '优惠券名称',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发放类型 0下单赠送1 指定发放 2 免费领取',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠券金额',
  `condition` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '使用条件',
  `createnum` int(11) NOT NULL DEFAULT '0' COMMENT '发放数量',
  `send_num` int(11) NOT NULL DEFAULT '0' COMMENT '已领取数量',
  `use_num` int(11) NOT NULL DEFAULT '0' COMMENT '已使用数量',
  `send_start_time` varchar(30) NOT NULL DEFAULT '' COMMENT '发放开始时间',
  `send_end_time` varchar(30) NOT NULL DEFAULT '' COMMENT '发放结束时间',
  `use_start_time` varchar(30) NOT NULL DEFAULT '' COMMENT '使用开始时间',
  `use_end_time` varchar(30) NOT NULL DEFAULT '' COMMENT '使用结束时间',
  `add_time` varchar(30) NOT NULL DEFAULT '' COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `use_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '使用范围：0全店通用 1指定商品可用 2指定分类商品可用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_coupon
-- ----------------------------

-- ----------------------------
-- Table structure for frame_coupon_list
-- ----------------------------
DROP TABLE IF EXISTS `frame_coupon_list`;
CREATE TABLE `frame_coupon_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0' COMMENT '优惠券id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '发放类型 0下单赠送1 指定发放 2 免费领取',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单id',
  `use_time` varchar(30) NOT NULL DEFAULT '' COMMENT '优惠券使用时间',
  `send_time` varchar(30) NOT NULL DEFAULT '' COMMENT '优惠券的发放时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 未使用 1 已使用 2 已过期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_coupon_list
-- ----------------------------

-- ----------------------------
-- Table structure for frame_delivery
-- ----------------------------
DROP TABLE IF EXISTS `frame_delivery`;
CREATE TABLE `frame_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单id',
  `order_sn` varchar(100) NOT NULL DEFAULT '' COMMENT '订单编号',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `admin_id` int(11) NOT NULL DEFAULT '0' COMMENT '管理员id',
  `consignee` varchar(30) NOT NULL DEFAULT '' COMMENT '收货人',
  `zipcode` varchar(30) NOT NULL DEFAULT '' COMMENT '邮编',
  `mobile` varchar(30) NOT NULL DEFAULT '' COMMENT '手机号',
  `province` varchar(30) NOT NULL DEFAULT '' COMMENT '省份',
  `city` varchar(30) NOT NULL DEFAULT '' COMMENT '市区',
  `district` varchar(50) NOT NULL DEFAULT '' COMMENT '县',
  `address` varchar(100) NOT NULL DEFAULT '' COMMENT '地址',
  `shipping_code` varchar(50) NOT NULL DEFAULT '' COMMENT '物流code',
  `shipping_name` varchar(50) NOT NULL DEFAULT '' COMMENT '快递名称',
  `shipping_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '运费',
  `invoice_no` varchar(70) NOT NULL DEFAULT '' COMMENT '物流单号',
  `tel` varchar(60) NOT NULL DEFAULT '' COMMENT '座机号码',
  `note` varchar(100) NOT NULL DEFAULT '' COMMENT '管理员添加的备注信息',
  `create_time` varchar(30) NOT NULL DEFAULT '' COMMENT '创建时间',
  `best_time` varchar(30) NOT NULL DEFAULT '' COMMENT '友好收货时间',
  `send_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发货方式0自填快递1在线预约2电子面单3无需物流',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_delivery
-- ----------------------------

-- ----------------------------
-- Table structure for frame_freight_config
-- ----------------------------
DROP TABLE IF EXISTS `frame_freight_config`;
CREATE TABLE `frame_freight_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_unit` double(16,4) NOT NULL DEFAULT '0.0000' COMMENT '首(重：体积：件）',
  `first_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '首(重：体积：件）运费',
  `continue_unit` double(16,4) NOT NULL DEFAULT '0.0000' COMMENT '继续加（件：重量：体积）区间',
  `continue_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '首(重：体积：件）运费',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '运费模板ID',
  `region` varchar(200) NOT NULL DEFAULT '' COMMENT '区域',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是默认运费配置.0不是，1是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_freight_config
-- ----------------------------

-- ----------------------------
-- Table structure for frame_freight_template
-- ----------------------------
DROP TABLE IF EXISTS `frame_freight_template`;
CREATE TABLE `frame_freight_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '模板名称',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 件数；1 商品重量；2 商品体积',
  `is_enable_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否启用使用默认运费配置,0:不启用，1:启用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_freight_template
-- ----------------------------

-- ----------------------------
-- Table structure for frame_friendly
-- ----------------------------
DROP TABLE IF EXISTS `frame_friendly`;
CREATE TABLE `frame_friendly` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '链接名称',
  `url` varchar(50) NOT NULL DEFAULT '' COMMENT '链接地址',
  `logo` varchar(50) NOT NULL DEFAULT '' COMMENT '链接logo',
  `sort` tinyint(4) NOT NULL DEFAULT '0',
  `is_show` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `target` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1为新窗口打开，0为当前打开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_friendly
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods`;
CREATE TABLE `frame_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `goods_name` varchar(100) NOT NULL DEFAULT '' COMMENT '商品名称',
  `goods_remark` varchar(200) NOT NULL COMMENT '商品简介',
  `cate_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品分类id',
  `goods_sn` varchar(20) NOT NULL DEFAULT '' COMMENT '商品编号',
  `click_count` int(11) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `weight` int(11) NOT NULL DEFAULT '0' COMMENT '商品的重量',
  `volume` int(11) NOT NULL DEFAULT '0' COMMENT '商品的体积',
  `is_free_shipping` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否包邮',
  `store_count` int(11) NOT NULL DEFAULT '0' COMMENT '库存',
  `shop_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '售价',
  `market_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `original_img` varchar(150) NOT NULL DEFAULT '' COMMENT '商品原始主图',
  `video` varchar(50) NOT NULL DEFAULT '' COMMENT '视频',
  `keywords` varchar(100) NOT NULL DEFAULT '' COMMENT '关键词',
  `details` text NOT NULL COMMENT '商品详情',
  `model_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '商品对应的模型',
  `is_recommend` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否推荐商品',
  `is_on_sale` tinyint(4) NOT NULL DEFAULT '0' COMMENT '上下架',
  `on_time` varchar(20) NOT NULL DEFAULT '0' COMMENT '商品上架时间',
  `last_update` varchar(20) NOT NULL DEFAULT '0' COMMENT '商品最后更新时间',
  `template_id` int(11) NOT NULL DEFAULT '0' COMMENT '运费模板id',
  `give_integral` mediumint(8) NOT NULL DEFAULT '0' COMMENT '购买商品赠送积分',
  `exchange_integral` int(11) NOT NULL DEFAULT '0' COMMENT '积分兑换：0不参与积分兑换',
  `sales_sum` int(11) NOT NULL DEFAULT '0' COMMENT '商品销量',
  PRIMARY KEY (`id`),
  UNIQUE KEY `goods_name` (`goods_name`,`goods_sn`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_attr
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_attr`;
CREATE TABLE `frame_goods_attr` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品属性id',
  `attr_name` varchar(30) NOT NULL DEFAULT '' COMMENT '商品属性名称',
  `model_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品模型id',
  `input_mode` int(11) NOT NULL DEFAULT '0' COMMENT '商品属性输入类型，0为手工录入，1为列表',
  `attr_value` varchar(100) NOT NULL DEFAULT '' COMMENT '商品属性输入类型为1时，需要填值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods_attr
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_attr_value
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_attr_value`;
CREATE TABLE `frame_goods_attr_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品属性id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `attr_id` int(11) NOT NULL DEFAULT '0' COMMENT '属性id',
  `attr_value` text NOT NULL COMMENT '属性值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=170 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods_attr_value
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_cate
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_cate`;
CREATE TABLE `frame_goods_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品分类id',
  `cate_name` varchar(50) NOT NULL DEFAULT '0' COMMENT '商品分类名称',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父级id',
  `icon` varchar(100) NOT NULL DEFAULT '' COMMENT '图标',
  `sort` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cate_name` (`cate_name`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods_cate
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_coupon
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_coupon`;
CREATE TABLE `frame_goods_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_id` int(11) NOT NULL DEFAULT '0' COMMENT '优惠券id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '指定的商品id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods_coupon
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_img
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_img`;
CREATE TABLE `frame_goods_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `img` varchar(100) NOT NULL DEFAULT '' COMMENT '商品组图',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods_img
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_model
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_model`;
CREATE TABLE `frame_goods_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '模型id',
  `model_name` varchar(20) NOT NULL DEFAULT '' COMMENT '模型名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `model_name` (`model_name`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods_model
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_spec
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_spec`;
CREATE TABLE `frame_goods_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_name` varchar(30) NOT NULL DEFAULT '' COMMENT '规格名称',
  `model_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品模型id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_goods_spec
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_spec_img
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_spec_img`;
CREATE TABLE `frame_goods_spec_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品规格图片id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `spec_item_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品规格id',
  `img` varchar(128) NOT NULL COMMENT '商品规格图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='商品规格图片 商品规格图片';

-- ----------------------------
-- Records of frame_goods_spec_img
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_spec_item
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_spec_item`;
CREATE TABLE `frame_goods_spec_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '规格值id',
  `spec_id` int(11) NOT NULL COMMENT '规格id',
  `item` varchar(32) NOT NULL COMMENT '规格值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='商品规格值表 商品规格值表';

-- ----------------------------
-- Records of frame_goods_spec_item
-- ----------------------------

-- ----------------------------
-- Table structure for frame_goods_spec_price
-- ----------------------------
DROP TABLE IF EXISTS `frame_goods_spec_price`;
CREATE TABLE `frame_goods_spec_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品规格价id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `key` varchar(32) NOT NULL COMMENT '规格键名',
  `key_name` varchar(128) NOT NULL COMMENT '规格键名中文',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `store` int(11) NOT NULL DEFAULT '0' COMMENT '库存',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '此规格是否有效',
  `prom_id` int(11) NOT NULL DEFAULT '0' COMMENT '活动id',
  `prom_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动类型',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='商品规格价 商品规格价';

-- ----------------------------
-- Records of frame_goods_spec_price
-- ----------------------------

-- ----------------------------
-- Table structure for frame_invoice
-- ----------------------------
DROP TABLE IF EXISTS `frame_invoice`;
CREATE TABLE `frame_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_title` tinyint(50) NOT NULL DEFAULT '0' COMMENT '发票抬头 0 个人 1 公司',
  `unit_name` varchar(50) NOT NULL DEFAULT '' COMMENT '单位名称',
  `taxpayer_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '纳税人类型 0=增值税 1=非增值税',
  `taxpayer` varchar(100) NOT NULL DEFAULT '' COMMENT '纳税人识别号',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 不开发票 1需开发票 2暂不开票 3已开发票',
  `order_sn` varchar(100) NOT NULL DEFAULT '' COMMENT '订单编号',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `complete_time` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_invoice
-- ----------------------------

-- ----------------------------
-- Table structure for frame_navigation
-- ----------------------------
DROP TABLE IF EXISTS `frame_navigation`;
CREATE TABLE `frame_navigation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '导航名称',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `is_new` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否新窗口打开',
  `sort` int(11) NOT NULL DEFAULT '1' COMMENT '排序',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT '链接地址',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_navigation
-- ----------------------------

-- ----------------------------
-- Table structure for frame_order
-- ----------------------------
DROP TABLE IF EXISTS `frame_order`;
CREATE TABLE `frame_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(50) NOT NULL DEFAULT '' COMMENT '订单编号',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `order_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单状态 0未确定 1已确定 2已收货 3已取消 4已完成 5为作废订单',
  `shipping_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发货状态 0 未发货 1已发货 2部分发货 3退货 4换货',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态 0 未支付 1已支付 2审核中 3支付异常 4退款',
  `consignee` varchar(20) NOT NULL DEFAULT '' COMMENT '收货人',
  `province` varchar(20) NOT NULL DEFAULT '' COMMENT '省份',
  `city` varchar(20) NOT NULL DEFAULT '' COMMENT '地区',
  `district` varchar(30) NOT NULL DEFAULT '' COMMENT '县区',
  `address` varchar(100) NOT NULL DEFAULT '' COMMENT '地址',
  `zipcode` varchar(20) NOT NULL DEFAULT '' COMMENT '邮编',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号',
  `shipping_code` varchar(50) NOT NULL DEFAULT '' COMMENT '物流code',
  `shipping_name` varchar(20) NOT NULL DEFAULT '' COMMENT '物流名称',
  `pay_code` varchar(50) NOT NULL DEFAULT '' COMMENT '支付code',
  `pay_name` varchar(20) NOT NULL DEFAULT '' COMMENT '支付方式名称',
  `invoice_title` varchar(20) NOT NULL DEFAULT '' COMMENT '发票抬头',
  `goods_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品总价',
  `shipping_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '邮费',
  `coupon_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠券抵扣',
  `order_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '应付款金额',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单总价',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '0为普通商品',
  `give_integral` int(11) NOT NULL DEFAULT '0' COMMENT '订单内商品赠送的总积分 0则为积分商品',
  `add_time` varchar(20) NOT NULL DEFAULT '' COMMENT '用户下单时间',
  `shipping_time` varchar(20) NOT NULL DEFAULT '' COMMENT '最后发货时间',
  `confirm_time` varchar(20) NOT NULL DEFAULT '' COMMENT '收货确认时间',
  `pay_time` varchar(20) NOT NULL DEFAULT '' COMMENT '支付时间',
  `transaction_id` varchar(100) NOT NULL DEFAULT '' COMMENT '第三方平台交易流水号',
  `user_note` varchar(200) NOT NULL DEFAULT '' COMMENT '用户备注',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格调整',
  `admin_note` varchar(100) NOT NULL DEFAULT '' COMMENT '管理员备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_sn` (`order_sn`,`transaction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_order
-- ----------------------------

-- ----------------------------
-- Table structure for frame_order_action
-- ----------------------------
DROP TABLE IF EXISTS `frame_order_action`;
CREATE TABLE `frame_order_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` mediumint(9) NOT NULL DEFAULT '0' COMMENT '订单id',
  `action_user` int(11) NOT NULL DEFAULT '0' COMMENT '操作人 0 为用户操作，其他为管理员id',
  `order_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单状态',
  `shipping_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '配送状态',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态',
  `action_note` varchar(200) NOT NULL DEFAULT '' COMMENT '操作备注',
  `log_time` varchar(20) NOT NULL DEFAULT '' COMMENT '操作时间',
  `status_desc` varchar(100) NOT NULL DEFAULT '' COMMENT '状态描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_order_action
-- ----------------------------

-- ----------------------------
-- Table structure for frame_order_goods
-- ----------------------------
DROP TABLE IF EXISTS `frame_order_goods`;
CREATE TABLE `frame_order_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单id',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `goods_name` varchar(120) NOT NULL DEFAULT '' COMMENT '商品名称',
  `goods_sn` varchar(50) NOT NULL DEFAULT '' COMMENT '商品货号',
  `goods_num` smallint(5) NOT NULL DEFAULT '0' COMMENT '购买数量',
  `goods_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '本店价',
  `goods_integral` int(11) NOT NULL DEFAULT '0' COMMENT '商品积分 大于0为积分商品',
  `member_goods_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '会员折扣价',
  `is_comment` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否评价',
  `is_reminder` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否催单',
  `is_send` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未发货，1已发货，2已换货，3已退货',
  `give_integral` int(11) NOT NULL DEFAULT '0' COMMENT '赠送的积分',
  `delivery_id` int(11) NOT NULL DEFAULT '0' COMMENT '发货单id',
  `spec_key` varchar(30) NOT NULL DEFAULT '' COMMENT '商品规格key',
  `spec_key_name` varchar(100) NOT NULL DEFAULT '' COMMENT '规格对应的中文名字',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_order_goods
-- ----------------------------

-- ----------------------------
-- Table structure for frame_pay_record
-- ----------------------------
DROP TABLE IF EXISTS `frame_pay_record`;
CREATE TABLE `frame_pay_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(50) NOT NULL DEFAULT '' COMMENT '订单编号',
  `order_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '订单价格',
  `pay_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付金额',
  `pay_status` int(11) NOT NULL DEFAULT '0' COMMENT '支付状态 1支付成功 4退款 3支付异常',
  `pay_time` varchar(20) NOT NULL DEFAULT '' COMMENT '支付时间',
  `pay_desc` varchar(100) NOT NULL COMMENT '支付描述',
  `transaction_id` varchar(50) NOT NULL COMMENT '支付订单号',
  `pay_code` varchar(30) NOT NULL COMMENT '支付code',
  `pay_name` varchar(30) NOT NULL COMMENT '支付方式名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_pay_record
-- ----------------------------

-- ----------------------------
-- Table structure for frame_plugin
-- ----------------------------
DROP TABLE IF EXISTS `frame_plugin`;
CREATE TABLE `frame_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '插件编码',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '插件名字',
  `version` varchar(50) NOT NULL DEFAULT '' COMMENT '插件的版本',
  `author` varchar(30) NOT NULL DEFAULT '' COMMENT '插件作者',
  `config` text NOT NULL COMMENT '配置信息',
  `config_value` text NOT NULL COMMENT '配置值信息',
  `desc` varchar(200) NOT NULL DEFAULT '' COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否启用',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '插件类型 payment支付 login 登陆 shipping物流',
  `icon` varchar(200) NOT NULL DEFAULT '' COMMENT '图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`,`name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_plugin
-- ----------------------------
INSERT INTO `frame_plugin` VALUES ('1', 'weixin', '微信', '1.0', 'admin', 'a:4:{i:0;a:4:{s:4:\"name\";s:5:\"appid\";s:5:\"label\";s:20:\"绑定支付的APPID\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}i:1;a:4:{s:4:\"name\";s:5:\"mchid\";s:5:\"label\";s:9:\"商户号\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}i:2;a:4:{s:4:\"name\";s:3:\"key\";s:5:\"label\";s:18:\"商户支付密钥\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}i:3;a:4:{s:4:\"name\";s:9:\"appsecret\";s:5:\"label\";s:18:\"公众帐号secert\";s:4:\"type\";s:57:\"公众帐号secert（仅JSAPI支付的时候需要配置)\";s:6:\"status\";i:0;}}', 'a:4:{s:5:\"appid\";s:18:\"wx426b3015555a46be\";s:5:\"mchid\";s:10:\"1900009851\";s:3:\"key\";s:32:\"8934e7d15453e97507ef794cf7b0519d\";s:9:\"appsecret\";s:32:\"7813490da6f1265e4901ffb80afaa36f\";}', '微信支付插件 ', '1', 'payment', '/static/common/images/wechat.png');
INSERT INTO `frame_plugin` VALUES ('2', 'alipay', '支付宝', '1.0', 'admin', 'a:3:{i:0;a:4:{s:4:\"name\";s:6:\"app_id\";s:5:\"label\";s:5:\"APPID\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}i:1;a:4:{s:4:\"name\";s:20:\"merchant_private_key\";s:5:\"label\";s:12:\"商户私钥\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}i:2;a:4:{s:4:\"name\";s:17:\"alipay_public_key\";s:5:\"label\";s:15:\"支付宝公钥\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}}', 'a:3:{s:6:\"app_id\";s:16:\"2018073060802751\";s:20:\"merchant_private_key\";s:1592:\"MIIEpAIBAAKCAQEApbifikkgeC1dhl9XptzVcszaHut0+1WR0BuVkuzwC93irU5TZFtt0Td3l18ZvThTOeT+3VxgYYvrn6dNR6RcxtwCubyJy7mxHSoHwSYMJrPqcPZyiWNrJszhS6teZfv/vgy6psEK8f6/gEJyjJcbWAipv89t32AwkbdfFLHFmomR5IBHCSbRkWSRDMuV8v3Z5csBtpJxtNFCPCmKYYiuBSSOlaStApAwCV8ggT4ZLnHdAE1jCqVikgBn/0hfMgQw1SqKLykj9hmbCXoF5A6Et9UO9kaAKkyBhfOXnHd1TvebUwLIcBl2EninvZ7rQ2O2HXg0Iq69XMVm1u611LdG5wIDAQABAoIBAGtMg7fkqypErTZwiu8WMvm2m0/DwiVtfRCSm6Da2n3Ed50ghqwG6q64zCztPVwfmPt2QnKO+jSOhMwFZesKB6wWDYm3Aj0vCPdKHGU5vkpc2WG0n+pGvb0MkJ8O4PsFU8v4r+2CNhUDjXh9DW/r8p9oVIhFxO0JeckPQnfCtp/cggxMiZk0ZRvJwMi1Gm1LGX457W4AfOUaa4teiksql3OV7YIXntVU7tHc8g/UNfhJ0m7IOUd4NsBOnBwDf+TyOY1I3m06gTkk+3rWEPOsAVQza9K/Lk78qGNUl7XwKXRtDgTMwMlBluXF/uBWE73jHbkKjoDVhqNkW8sb1JgBVNECgYEA1BBfGv/L1Iu89XoFnjRNs1fedhzYp39jCzurMYLabDW7nfl1Vv+7gyp+N1at6Gg9cSpagicFWtPM9W+nTewapMV28a20DrKsJZ/3FFXXby+W+4db5TQ1FLlsWdVm7bXQ4vk2O3F2Vlw55cQgvwaT5gS75tjPDxXl+tRn2o68PH8CgYEAyA5I2I2KFJR7U+j8c4pcQBozpAdYuZP9kWudnlFkw88fw7rtsmtfaQAJnb4X9AfT0Nr4ZflODU1jEFPLu9MPgpF7VVVO18nwYkhQfZPz7ipVbHMjuENEMBnAVne2d1FLbzy7s/ZHeBBG38/fBtnb07cq4+nC3sJEO58/1NM1YZkCgYEA045RkrnFOpD9PVcx65X6PgRW5jX43YBz6mzoaEhGZtVkCkEnElelVUE7ETHj5Iq5YQADsvwCl43cVq3AljgIjICCHLBRhKgynIZtE1hfx4gOc3eh8ZKXsckZkrUWLebIMOa1d6/FgnoXOGTk1i1Vto7adX2tcztBZ24m/R6QIzkCgYAsJjLfT4Uce5Qn9W/ZE7y+DMo+tbxX4BgCgqxbJv1E1S3eZR9V06pPosl8fVoN6bhODDTrVDRsbRqinMuGXNK8bty3/UaUCqW5GtpgjEk10zPc5iAI5xdiQhyXOH4VIOSz3MRTt9MX5QevFtHSUjvYIkEd4RW3UUn7mm5cymuqaQKBgQC2SqVdgDtYW6oMgSu0K6EZWVHYkHDUkREWvDDYQ6MF9YQfkRfQJSyrS4pSxuu6JiNSwG4atfJJmDcV+JJY4kgUx1QioTE1/sT81J5KO93oCoC49HkUHvWJYFjYwfGKxTNiURaZQQQDqDMAL6V9f5fBrOq3/qDfzvnAGl+TMoVEAg==\";s:17:\"alipay_public_key\";s:701:\"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAl7x61u7plJVe24tbuaJcE4/W2MqJCZXet6fxSuangrdRoKcSq1h5coRiu1nR60X1ai/Jctj4DGFNv6cDh9TM4ERqtPB6BJ5jyDxkaBPYBMj4d2V4CAeYgX5XM9tcSxZHdC3Bik0qQCAwQPZPF1AR/XMhsOYgiqF2v5QsxLksyz7ZidsVIDV6btXFFr1suH5o+qRTYvaYVEr4lSHBrh8uqzvid/19fXMu1I5WRsLNJP2quRYn2Q7T7I7oKeSBkzNWRqhb69YVEMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAkJWZJnWsHZWs8PnGPEB1PaFLK9ViNUkB+viBc2XzTunIWWeCAqwlBkx9eWr8o8MZ9IdIrvS25pM7LlgZsPHW3g2nyTglyCQGDnQ8GjJk2lWtAtPtjN/v+3RI5qnZeRpQWwco6fQ4kizyRPDMlW0bYZLQCPeWPgezCLoM28uvCrRaJar9UPF7rbTimh/VwWOQsPng5t7T0VqKwm7tYJnmbz7SxiNOxkMiaskBq6z55cJGqhm9qvCthN2fW61qq10HhYd0wTWvTX3ZG4XRxo7YNoqm1nPmMxb+SwSDiUaBGNeko1CMXJF4jvD0//s7Wtu3LLeCHnLuLCjKus4txue9rQIDAQAB\";}', 'PC端支付宝插件 ', '1', 'payment', '/static/common/images/alipay.png');
INSERT INTO `frame_plugin` VALUES ('3', 'aliyun', '短信验证', '1.0', 'admin', 'a:4:{i:0;a:4:{s:4:\"name\";s:10:\"access_key\";s:5:\"label\";s:9:\"AccessKey\";s:4:\"type\";s:39:\"获取：https://ak-console.aliyun.com/\";s:6:\"status\";i:1;}i:1;a:4:{s:4:\"name\";s:13:\"access_secret\";s:5:\"label\";s:15:\"AccessKeySecret\";s:4:\"type\";s:39:\"获取：https://ak-console.aliyun.com/\";s:6:\"status\";i:1;}i:2;a:4:{s:4:\"name\";s:12:\"signers_name\";s:5:\"label\";s:12:\"签名名称\";s:4:\"type\";s:66:\"请参考 https://dysms.console.aliyun.com/dysms.htm#/develop/sign\";s:6:\"status\";i:1;}i:3;a:4:{s:4:\"name\";s:13:\"template_code\";s:5:\"label\";s:16:\"短信模板CODE\";s:4:\"type\";s:70:\"请参考 https://dysms.console.aliyun.com/dysms.htm#/develop/template\";s:6:\"status\";i:1;}}', 'a:4:{s:10:\"access_key\";s:16:\"LTAItuA2HpbQ9VZr\";s:13:\"access_secret\";s:30:\"7hr6FeabZ0Ps1agTGYnqFZ7GRzw585\";s:12:\"signers_name\";s:12:\"不弃梦想\";s:13:\"template_code\";s:13:\"SMS_148080973\";}', '阿里云短信验证', '1', 'sms', '/static/common/images/alissms.png');
INSERT INTO `frame_plugin` VALUES ('4', 'express', '快递查询', '1.0', 'admin', 'a:2:{i:0;a:4:{s:4:\"name\";s:11:\"EBusinessID\";s:5:\"label\";s:8:\"用户ID\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}i:1;a:4:{s:4:\"name\";s:6:\"AppKey\";s:5:\"label\";s:7:\"API key\";s:4:\"type\";s:0:\"\";s:6:\"status\";i:1;}}', 'a:2:{s:11:\"EBusinessID\";s:7:\"1393875\";s:6:\"AppKey\";s:36:\"c5ac5681-a1bd-45d6-8b44-8a05fe53bf1f\";}', '快递鸟提供', '1', 'shipping', '/static/common/images/courierbird.png');

-- ----------------------------
-- Table structure for frame_return_goods
-- ----------------------------
DROP TABLE IF EXISTS `frame_return_goods`;
CREATE TABLE `frame_return_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `res_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单商品id',
  `order_id` int(11) NOT NULL DEFAULT '0' COMMENT '订单id',
  `order_sn` varchar(40) NOT NULL DEFAULT '' COMMENT '订单编号',
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `goods_num` int(11) NOT NULL DEFAULT '0' COMMENT '商品数量',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0仅退款 1退货退款 2换货',
  `reason` varchar(200) NOT NULL DEFAULT '' COMMENT '退款原因',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '问题描述',
  `imgs` text NOT NULL COMMENT '拍照图片路径',
  `addtime` varchar(30) NOT NULL DEFAULT '' COMMENT '申请时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-2用户取消-1不同意0待审核1通过2已发货3已收货4换货完成5退款完成',
  `remark` varchar(200) NOT NULL DEFAULT '' COMMENT '客服备注',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `spec_key` varchar(50) NOT NULL DEFAULT '' COMMENT '商品规格key 对应tp_spec_goods_price 表',
  `seller_delivery` text NOT NULL COMMENT '换货服务，卖家重新发货信息',
  `refund_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '退还金额',
  `refund_deposit` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '退还余额',
  `refund_integral` int(11) NOT NULL DEFAULT '0' COMMENT '退还积分',
  `refund_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '退款类型 1退款金额 2退款余额 3退款积分',
  `refund_mark` varchar(255) NOT NULL DEFAULT '' COMMENT '退款备注',
  `refund_time` varchar(30) NOT NULL DEFAULT '' COMMENT '退款时间',
  `is_receive` tinyint(1) NOT NULL DEFAULT '0' COMMENT '申请售后时是否收到货物',
  `delivery` text NOT NULL COMMENT '用户发货信息',
  `checktime` varchar(30) NOT NULL DEFAULT '' COMMENT '卖家审核时间',
  `receivetime` varchar(30) NOT NULL DEFAULT '' COMMENT '卖家收货时间',
  `canceltime` varchar(30) NOT NULL DEFAULT '' COMMENT '用户取消时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_return_goods
-- ----------------------------
INSERT INTO `frame_return_goods` VALUES ('1', '27', '31', '123412412341234', '27', '0', '1', '', '', '', '1542694358', '3', '123412', '16', '17_13', 'a:3:{s:12:\"express_name\";s:12:\"顺丰快递\";s:10:\"express_sn\";s:10:\"1243812347\";s:12:\"express_time\";i:1542772439;}', '200.00', '0.00', '0', '1', '', '', '0', 'a:3:{s:12:\"express_name\";s:12:\"顺丰快递\";s:10:\"express_sn\";s:12:\"123412342134\";s:12:\"express_time\";s:10:\"1542765230\";}', '1542773281', '1542773301', '');

-- ----------------------------
-- Table structure for frame_shipping
-- ----------------------------
DROP TABLE IF EXISTS `frame_shipping`;
CREATE TABLE `frame_shipping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shipping_name` varchar(30) NOT NULL DEFAULT '' COMMENT '物流公司名称',
  `shipping_code` varchar(80) NOT NULL DEFAULT '' COMMENT '物流公司编码',
  `is_open` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `shipping_desc` varchar(200) NOT NULL DEFAULT '' COMMENT '物流描述',
  `shipping_logo` varchar(100) NOT NULL DEFAULT '' COMMENT '物流公司logo',
  `template_width` int(11) NOT NULL DEFAULT '0' COMMENT '运单模板宽度',
  `template_height` int(11) NOT NULL DEFAULT '0' COMMENT '运单模板高度',
  `template_offset_x` int(11) NOT NULL DEFAULT '0' COMMENT '运单模板左偏移量',
  `template_offset_y` int(11) NOT NULL DEFAULT '0' COMMENT '运单模板上偏移量',
  `template_img` varchar(100) NOT NULL DEFAULT '' COMMENT '运单模板图片',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shipping_name` (`shipping_name`,`shipping_code`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_shipping
-- ----------------------------

-- ----------------------------
-- Table structure for frame_users
-- ----------------------------
DROP TABLE IF EXISTS `frame_users`;
CREATE TABLE `frame_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名称',
  `password` varchar(50) NOT NULL DEFAULT '' COMMENT '密码',
  `contacts` varchar(30) NOT NULL DEFAULT '' COMMENT '联系人',
  `paypwd` varchar(50) NOT NULL DEFAULT '' COMMENT '用户支付密码',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号',
  `email` varchar(20) NOT NULL DEFAULT '' COMMENT '邮箱',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0：男  1：女  2：保密',
  `birthday` varchar(20) NOT NULL DEFAULT '' COMMENT '生日',
  `user_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '用户余额',
  `reg_time` varchar(20) NOT NULL DEFAULT '' COMMENT '用户注册时间',
  `last_login` varchar(20) NOT NULL DEFAULT '' COMMENT '最后登录时间',
  `last_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `qq_open_id` varchar(50) NOT NULL DEFAULT '' COMMENT 'qq的open_id',
  `wx_open_id` varchar(50) NOT NULL DEFAULT '' COMMENT '微信的open_id',
  `oauth` varchar(10) NOT NULL DEFAULT '' COMMENT '第三方注册 wx qq',
  `head_pic` varchar(80) NOT NULL DEFAULT '' COMMENT '用户头像',
  `province` int(6) NOT NULL DEFAULT '0' COMMENT '省',
  `city` int(6) NOT NULL DEFAULT '0' COMMENT '市',
  `district` int(6) NOT NULL DEFAULT '0' COMMENT '县',
  `level` tinyint(1) NOT NULL DEFAULT '1' COMMENT '会员等级',
  `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '用户累计消费余额',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '用户剩余积分',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户是否被启用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`mobile`,`email`,`qq_open_id`,`wx_open_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_users
-- ----------------------------
INSERT INTO `frame_users` VALUES ('16', 'feilx', 'a5e9953281a35d1865b94a61433b26c4', '', '', '18736487654', '', '0', '', '0.00', '1542608091', '', '', '', '', '', '', '0', '0', '0', '5', '0.00', '0', '1');

-- ----------------------------
-- Table structure for frame_user_address
-- ----------------------------
DROP TABLE IF EXISTS `frame_user_address`;
CREATE TABLE `frame_user_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `consignee` varchar(30) NOT NULL DEFAULT '' COMMENT '收货人名称',
  `province` varchar(20) NOT NULL DEFAULT '' COMMENT '省份',
  `city` varchar(20) NOT NULL DEFAULT '' COMMENT '城市',
  `district` varchar(20) NOT NULL DEFAULT '' COMMENT '地区',
  `address` varchar(100) NOT NULL DEFAULT '' COMMENT '地址',
  `zipcode` varchar(20) NOT NULL DEFAULT '' COMMENT '邮政编码',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '默认收货地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_user_address
-- ----------------------------

-- ----------------------------
-- Table structure for frame_user_collection
-- ----------------------------
DROP TABLE IF EXISTS `frame_user_collection`;
CREATE TABLE `frame_user_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品id',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_user_collection
-- ----------------------------

-- ----------------------------
-- Table structure for frame_user_level
-- ----------------------------
DROP TABLE IF EXISTS `frame_user_level`;
CREATE TABLE `frame_user_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level_name` varchar(20) NOT NULL DEFAULT '' COMMENT '头衔名称',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '达到此会员需要的金额',
  `discount` smallint(4) NOT NULL DEFAULT '0' COMMENT '折扣',
  `describe` varchar(100) NOT NULL DEFAULT '' COMMENT '头街 描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `level_name` (`level_name`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of frame_user_level
-- ----------------------------
INSERT INTO `frame_user_level` VALUES ('5', '普通会员', '0.00', '100', '刚入坑的用户');
INSERT INTO `frame_user_level` VALUES ('6', '高级会员', '1000.00', '98', '已经一只脚踏入进去呢');
