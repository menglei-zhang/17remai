<?php 

namespace app\admin\model;

use think\Model;
use app\admin\validate\Freeca as Vali;

class Freeca extends Model
{
	/**
     * 福利卡列表
     */
	public function resList($id)
	{
		$query = $this->find($id);

		return $query;
	}


	/**
     * 福利卡添加/修改
     */
	public function editFreeca($data)
	{
		// 验证
        $validate = new Vali();
        if(!$validate->scene('form')->check($data)){
            return echoArr(0, $validate->getError());
        }

		// 修改福利卡
		if(isset($data['id'])){
			$result = $this->allowField(true)->isUpdate(true)->save($data);
	        if(false === $result){
	        	return echoArr(0, $result->getError());
	        }else{
	        	return echoArr(1, '修改成功');
	        }
		}

		// 福利卡生成
		$number = $this->order('freeca_code DESC')->find();
		$num = 0;
		for ($i = 0; $i < $data['num']; $i++){
			$temp['money'] = $data['money'];
			$temp['add_time'] = time();

			// 福利卡号
			$num = $num + 1;
			$temp['freeca_code'] = date('ym') . str_pad(substr($number['freeca_code'], -4) + $num, 4, 0, STR_PAD_LEFT);

			$Freeca[] = $temp;
		}
		// 添加福利卡
		$result = $this->allowField(true)->isUpdate(false)->saveAll($Freeca);
        if(false === $result){
        	return echoArr(0, $result->getError());
        }else{
        	return echoArr(1, '添加成功');
        }
	}

	/**
     * 更改状态
     */
    public function editStatus($data)
    {
        // 验证
        $validate = new Vali();
        if(!$validate->scene('status')->check($data)){
            return echoArr(0, $validate->getError());
        }
        $result = $this->allowField(true)->isUpdate(true)->save($data);
        if(false === $result){
            return echoArr(0, $this->getError());
        }else{
            return echoArr(1, '操作成功');
        }
    }
}