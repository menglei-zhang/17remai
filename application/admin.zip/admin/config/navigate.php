<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: yunwuxin <448901948@qq.com>
// +----------------------------------------------------------------------

return [
    'admin/users' => [
        'name' => '会员管理',
        'action' => [
            'user' => '会员列表',
            'user_form' => '添加修改会员',
        ]
    ],

    'admin/component' => [
        'name' => '插件管理',
        'action' => [
            'plugin' => '插件列表',
            'plugin_form' => '添加修改插件',
        ]
    ],

    'admin/goods' => [
        'name' => '商品管理',
        'action' => [
            'goodsImg' => '商品分类',
            'goods' => '商品列表',
            'goodsImg_form' => '添加修改商品分类',
            'goods_form' => '添加修改商品',
        ]
    ],

    'admin/promotion' => [
        'name' => '促销管理',
        'action' => [
            'coupon' => '优惠券列表',
            'coupon_form' => '添加修改优惠券',
            'coupon_cat' => '查看优惠券',
            'coupon_send' => '发放优惠券',
            'bread' => '面包券列表',
            'bread_form' => '添加修改面包券',
            'bread_cat' => '查看面包券',
            'freeca' => '福利卡列表',
            'freeca_form' => '添加修改福利卡',
            'freeca_cat' => '查看福利卡',
        ]
    ],

    'admin/admin' => [
        'name' => '管理员管理',
        'action' => [
            'user' => '用户管理',
            'user_form' => '添加修改用户',
            'role' => '角色管理',
            'role_form' => '添加修改角色',
            'rule' => '权限管理',
            'rule_form' => '添加修改权限',
            'classify' => '权限分类',
            'classify_form' => '添加修改权限分类',
            'log' => '登录日志',
        ]
    ],

];
