<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/16
 * Time: 17:13
 */

namespace app\index\model;

use think\Model;
use app\index\model\GoodsImg;

class Goods extends Model
{
    public function getGoodsAll()
    {
        $data = $this->field('id,goods_name,shop_price,original_img')->limit(4)->select();
        
        foreach($data as $k => $v){
            $ip = $_SERVER['REQUEST_SCHEME']. '://' .$_SERVER['SERVER_NAME'];
            $data[$k]['original_img'] = $ip.'/uploads/'.$v['original_img'];
        }

        return $data;
    }

}
   