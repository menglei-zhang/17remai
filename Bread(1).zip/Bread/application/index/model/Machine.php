<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/16
 * Time: 17:13
 */

namespace app\index\model;

use think\Model;

class Machine extends Model
{
	public function resList($data, $decimal = 2)
	{
		$result = $this->where(['province'=>$data['province'], 'city'=>$data['city'], 'district'=>$data['district'], 'status'=>1])->field('bread_name,lng,lat,address')->select()->toArray();

		foreach($result as $key => $val){
			$earth_radius = 6378.137; 				// 地球半径
	        $lng1 = (M_PI / 180) * $data['lng'];	// 起始经度
	        $lng2 = (M_PI / 180) * $val['lng'];		// 结束经度
	        $lat1 = (M_PI / 180) * $data['lat'];	// 起始纬度
	        $lat2 = (M_PI / 180) * $val['lat'];		// 结束纬度

	        $d = acos(sin($lat1) * sin($lat2) + cos($lat1) * cos($lat2) * cos($lng2 - $lng1)) * $earth_radius;
		    $d = round($d, $decimal);
			$result[$key]['distance'] = $d;
		}

		rsort($result);

	    return $result;
	}


	public function resFind($info, $decimal = 2)
	{
		$result = $this->where('status', 1)->field('bread_name,lng,lat,address')->select()->toArray();

		foreach($result as $key => $val){


			$earth_radius = 6378.137; 				// 地球半径
	        $lng1 = (M_PI / 180) * $info['lng'];	// 起始经度
	        $lng2 = (M_PI / 180) * $val['lng'];		// 结束经度
	        $lat1 = (M_PI / 180) * $info['lat'];	// 起始纬度
	        $lat2 = (M_PI / 180) * $val['lat'];		// 结束纬度

	        $d = acos(sin($lat1) * sin($lat2) + cos($lat1) * cos($lat2) * cos($lng2 - $lng1)) * $earth_radius;
		    $d = round($d, $decimal);
			$result[$key]['distance'] = $d;
		}

		rsort($result);

	    return $result[0];
	}
}