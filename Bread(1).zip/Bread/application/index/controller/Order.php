<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/9/18
 * Time: 11:11
 */  
namespace app\index\controller;

use think\Controller;

class Order extends Controller
{
	/**
	 * @return 购买面包券
	 */
	public function index()
	{
		$data = input('post.');

		$result = model('Order')->buy($data);

		$result['user_money'] = model('Users')->where('id', $data['uid'])->sum('user_money');

		return json($result);
	}
}