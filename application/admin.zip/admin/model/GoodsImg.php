<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/15
 * Time: 15:44
 */

namespace app\admin\model;

use think\Model;
use app\admin\model\Goods;

class GoodsImg extends Model
{
	public function resList()
	{
		$Goods = new Goods();
		$query = $this->where(1);

		$goods = $this->select();
		// dump()
        $data = $query->order('goods_id ASC')->paginate(10, false, ['query'=>request()->param()]);

        return $data;
	}
}