<?php 

namespace app\admin\model;

use think\Model;
use app\admin\validate\Freeca as Vali;

class Freeca extends Model
{

}