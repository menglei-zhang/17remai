<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/16
 * Time: 17:13
 */

namespace app\index\model;

use think\Model;

class Bread extends Model
{
	public function resList($data)
	{
		if($data['code'] == 0){
			$result = $this->where('status', 0)->field('id,name,code,money,start_time,end_time,status')->select();
			foreach($result as $key => $val){
				$result[$key]['start_time'] = date('Y-m-d H:i:s', $val['start_time']);
				$result[$key]['end_time'] = date('Y-m-d H:i:s', $val['end_time']);
			}
		}else{
			$result = $this->where('status', 1)->field('id,name,code,money,start_time,end_time,status')->select();
			foreach($result as $key => $val){
				$result[$key]['start_time'] = date('Y-m-d H:i:s', $val['start_time']);
				$result[$key]['end_time'] = date('Y-m-d H:i:s', $val['end_time']);
			}
		}

		return $result;	
	}


	public function getBread()
	{
		$data = $this->field('name,money')->find();

		return $data;
	}
}