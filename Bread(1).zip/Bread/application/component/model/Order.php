<?php

namespace app\component\model;

use think\Model;

class Order extends Model{
  
}