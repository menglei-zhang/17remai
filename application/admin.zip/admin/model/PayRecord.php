<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/11/8
 * Time: 16:45
 */

namespace app\admin\model;


use think\Model;

class PayRecord extends Model
{

}