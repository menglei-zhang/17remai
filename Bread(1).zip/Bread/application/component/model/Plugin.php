<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/10/21
 * Time: 18:18
 */

namespace app\component\model;


use think\Model;

class Plugin extends Model
{
	
}