<?php
/**
 * Created by PhpStorm.
 * User: wzy12
 * Date: 2018/9/14
 * Time: 10:55
 */

namespace app\admin\model;


use think\Model;

class AdminRoleRule extends Model
{

}